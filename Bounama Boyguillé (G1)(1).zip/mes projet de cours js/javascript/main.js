// evenement sur la souris
const effet = document.querySelector(".effet");
const effetTitre = document.querySelector("h3");
window.addEventListener("mousemove", e => {
  //console.log("deplacement de la souris");
  // e traduit evenement nous fornit un ensemble de data sur l'enement en question
  //console.log(e);
  effet.style.left = e.pageX + "px";
  effet.style.top = e.pageY + "px";
});

effetTitre.addEventListener("mouseover", () => {
  effetTitre.classList.toggle("ausurvole");

  console.log(effetTitre);
});

// declaration des variable
const champ_pwd = document.getElementById("pwd");
const majuscule = document.getElementById("majuscule");
const minuscule = document.getElementById("minuscule");
const chiffre = document.getElementById("chiffre");
const longueur = document.getElementById("longueur");

// au clique sur le champ du mot de passe
// ancien methode d'utilisation
champ_pwd.onfocus = function() {
  document.getElementById("message").style.display = "block";
};

// quand on quitte sur le champ du mot de passe
champ_pwd.onblur = function() {
  document.getElementById("message").style.display = "none";
};

// verif password quand on commence la saisie

champ_pwd.onkeyup = function() {
  let estenminuscule = /[a-z]/g;
  let estenmajuscule = /[A-Z]/g;
  let estchiffre = /[0-9]/g;
  if (champ_pwd.value.match(estenminuscule)) {
    minuscule.classList.remove("invalide");
    minuscule.classList.add("valide");
  } else {
    minuscule.classList.remove("valide");
    minuscule.classList.add("invalide");
  }
  ///////////////// est un majuscule////////////////////////////
  if (champ_pwd.value.match(estenmajuscule)) {
    majuscule.classList.remove("invalide");
    majuscule.classList.add("valide");
  } else {
    majuscule.classList.remove("valide");
    majuscule.classList.add("invalide");
  }
  /////////////////// est chiffre/////////////////////////
  if (champ_pwd.value.match(estchiffre)) {
    chiffre.classList.remove("invalide");
    chiffre.classList.add("valide");
  } else {
    chiffre.classList.remove("valide");
    chiffre.classList.add("invalide");
  }
  /////////////////// tester la longueur/////////////////////////
  if (champ_pwd.value.length >= 8) {
    longueur.classList.remove("invalide");
    longueur.classList.add("valide");
  } else {
    longueur.classList.remove("valide");
    longueur.classList.add("invalide");
  }
};

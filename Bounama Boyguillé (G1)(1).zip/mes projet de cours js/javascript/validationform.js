const formulaire=document.getElementById('formulaire');
var username=document.getElementById('username');
var namme=document.getElementById('name');
var email=document.getElementById('email');
var phone=document.getElementById('phone');
var pwd=document.getElementById('pwd');
var pwd2=document.getElementById('pwd2');
const usernameError=document.getElementById('usernameError');
const nameError=document.getElementById('nameError');
const phoneNumberError=document.getElementById('phoneNumberError');
const conformityError=document.getElementById('conformityError');
function validation(event) {
	event.preventDefault();
	const usname=username.value;
	const nom=namme.value;
	const telephone=phone.value;
	const motdepass=pwd.value;
	const confirmer=pwd2.value;
	const nameRegex=/\d/;
	const phoneRegex=/[a-zA-Z]/g;
	let estvalide=true;
	if (usname.length < 3 || usname.length > 16){
		usernameError.textContent="Le nom d'utilisateur doit contenir entre 3 et 16 caracteres";
		estvalide=false;
	}
	else{
		usernameError.textContent="";
	}
	if (nameRegex.test(nom)){
		nameError.textContent="Le nom et le prénom ne doivent pas contenir de chiffres";
		estvalide=false;
	}
	else{
		nameError.textContent="";
	}
	if (phoneRegex.test(telephone)){
		phoneNumberError.textContent="Le numéro de téléphone ne doit pas contenir de lettres";
		estvalide=false;
	}
	else{
		phoneNumberError.textContent="";
	}
	if(motdepass !== confirmer){
		conformityError.textContent="Les mots de pass ne sont pas conformes";

		estvalide=false;
	}
	else{
		conformityError.textContent="";
	}
	if (estvalide){
		formulaire.submit();
		alert("L'inscription a bien réussie");
	}
}
formulaire.addEventListener('submit',validation);
let slideIndex=1;
showslide(slideIndex);
function suppslide(n){
	showslide(slideIndex+=n);
}
function showslide(n){
	let slides=document.querySelectorAll('.carousel-slide img');
	if(n > slides.length){
		slideIndex=1;
	}
	if(n < 1){
		slideIndex=slides.length;
	}
	for (let i = 0; i < slides.length;i++){
		slides[i].style.display='none';
	}
	slides[slideIndex -1].style.display='block';
}
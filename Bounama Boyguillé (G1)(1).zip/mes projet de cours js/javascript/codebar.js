//declaration des variables
const btn_cb=document.getElementById('btn_cb');
var text=document.querySelector('input');
let maboite=document.getElementById('box');
const impression=document.getElementById('impression');
const txterreur='<p class="erreur"> Remplissez le champ de texte!</p>';
const txttrop='<p class="erreur"> Le texte est trop long !</p>';

//teste des variable
//console.log(text);
/* btn_cb.onclick=function(){
    alert('je suis ok');
}*/
btn_cb.onclick=function(){
    if(text.value.length>0){
        if(text.value.length<50){
            // generer le code barre
            maboite.innerHTML="<svg id='barcode'></svg>";
            JsBarcode("#barcode",text.value);
            maboite.style.border='1px solde #999';
            // creer le boutton de telechargement
            impression.innerHTML='<button id="btn_cb" onclick="telechargerpdf()">Télécharger le code barre</button>';
            impression.style.marginTop='10px';
            impression.style.display='flex';
            
        }else{
            //gestion erreur quand texte trop long
            maboite.style.border=0;
            maboite.innerHTML=txttrop;
            impression.style.display='none';
            text.value='';
        }
    }else{
        // gestion erreur quand cest vide
        maboite.style.border=0;
        maboite.innerHTML=txterreur;
        impression.style.display='none';
    }
}
 
function telechargerpdf(){

var opt = {
  margin:       1,
  filename:    'auchan.pdf',
  image:        { type: 'jpeg', quality: 0.98 },
  html2canvas:  { scale: 2 },
  jsPDF:        { unit: 'in', format: 'a6', orientation: '1' }
};

// New Promise-based usage:
html2pdf().set(opt).from(maboite).save();

// Old monolithic-style usage:
html2pdf(maboite, opt);
}
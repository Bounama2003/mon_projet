// autre methode d'utilisation du js pour
// gerer les evenements celle que je vous recomende
const mabote = document.querySelector(".questionnaire");
const btn1 = document.getElementById("btn-1");
const btn2 = document.querySelector("#btn-2");
const reponse = document.querySelector(".reponse");
//console.log(reponse);
//placer un ecouteur d'evenement sur notre container
mabote.addEventListener("click", () => {
  mabote.classList.toggle("auClique");
  //mabote.classList.toggle("auClique");
});

btn1.addEventListener("click", () => {
  reponse.classList.add("afficheReponse");
  reponse.style.background = "green";
  sonVrai()
});

btn2.addEventListener("click", () => {
  reponse.classList.add("afficheReponse");
  reponse.style.background = "red";
  sonFaux()
});
//**************** */
const sonFaux = () => {
  const audio = new Audio();
  audio.src = "sonnerie/clap.mp3";
  audio.play();
};
const sonVrai = () => {
  const audio = new Audio();
  audio.src = "sonnerie/clap.mp3";
  audio.play();
};